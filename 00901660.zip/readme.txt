This is the deliverable for the AttendTrack website. All relevent links and information are in the contents.pdf.

If you are a new user, you must create an account. Then you will be able to log in. If there is an event available for check in, you will be presented with a dialog to do so.
Otherwise, you will be directed to the event list page.